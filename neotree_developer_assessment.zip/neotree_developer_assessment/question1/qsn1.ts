type ApiRecord = {
    record_id:string;
    [key:string]:unknown;

};

async function fetchRecords(apiUrl:string,token:string):Promise<ApiRecord[]>{
    const response =await fetch(apiUrl,{
        method :"POST"
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
        },
        body: 'token=${token}&content=record&format=jason',
    });

    const data = await response.json();
    return data.records;
}


// There is need to add exception handling so that when there is any error the app will not stop running or crush
// Also, since we are posting using Url its import for us to use parametriesed url which will reduce sql injection
/// Before return records its important for us to check if they are not defined so that we dont retrun undfined records