type UserInput ={
    name?: string;
    age?:string;
    email?:string;
    phone?:string;
};

function createUser(input:UserInput){
    if(!input.name || input.name.trim()==="" || input.name!==undefined){//its also import for to check if name input is undefined, its point less to store undefined name
        throw new Error("Name is required");
    }
    if (!input.email|| !input.email?.includes("@")|| len(input.email)<4){// Its also import for us to check the number of characters in the email becausse thre certain characters that makes the email invalid for example if the email is less than 2 characters then definately that email must not be valid
        throw new Error("Email is invalid"); // its also important for us check email does not contain other specila charcters that are not allowed on an email
    }
    if (typeof input.age !== "number" || input.age<18){
        throw new Error("Age is invalid");
    }
    if (input.phone?.trim()===""){
        throw new Error("if you input phone , it must not be blank")
       
    }
    return {name:input.name,email:input.email,age:input.age,phone:input.phone};
}

function updateUser(input:UserInput){
    if(input.name !==undefined && input.name?.trim()===""&& !input.name ){
        throw new Error("Name is required");
    }
    if (input.email!==undefined&& !input.email.includes("@")){
        throw new Error ("Email is invalid");
    }
    if (input.age !== undefined && (typeof input.age !=="number" || input.age <18)){
        throw new Error ("Age is invalid");
    }
    if (input.phone?.trim()===""){
        throw new Error("if you input phone , it must not be blank")
       
    }
    return input;
}

function importUser(row:Record<string,string>){
    const age = Number(row.age);
    if (!row.name || row.name.trim()==="" || row.name !==undefined){ //check the name value to import is defined 
        throw new Error ("Name is required");
    }
    if (!row.email || row.email.includes("@")){ /// also its important to chack length of our email
        throw new Error("Email is Invalid")
    }
    if (!age || age <18){
        throw new Error ("Age is invalid");
    }
    if (row.phone.trim()===""){
        throw new Error("if you input phone , it must not be blank")
       
    }
    return {name: row.name,email:row.email,age:row.age,phone:row.phone};
}

//Wheather to reject or remove unkown fieds
//Unkown fields must be remove because:
   // the purpose of these functions is to validate known fields so any unkown field passsed to this functions must be reject 
   // Also, ist complecated for us to valid date unkown fields henced must be remove
   // Also, if we accept unkown fields will complicate the solution and reduce its efficiency when perfoming operations