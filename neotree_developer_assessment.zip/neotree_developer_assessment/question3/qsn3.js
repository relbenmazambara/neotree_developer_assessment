//"3a" When payments are being processsed at the same whilist they are not ACID transactions 
//- There is a chance that lets say for example there two accounts and these accounts one account is the debt and the other one is the credit , If the logic is amount is deducted and then added to another account , due to network challenges account might be deducted without amount being added to the other account
// Also,if these two threads are not handled very well there is chance that if big number of users try to perform transactions using their accounts the complexity doubles and if not handled well there is chance that operations may overload the databases handling the complexity between accounts
/// also if logic of transactions is not validated there is a chance that there user can  make use of arithmetic between accounts and endup creating money from nothing.



const user ={id:1,balance:100};
async function savePayment(amount: float){
  return true;
}

async function addPayment(amount:number,requested_id:String,user_id:string) {
    const currentBalnce = user.balance;
    await savePayment(amount);
    if (savePayment(amount)){

    }
    user.balance = currentBalnce + amount
    return user.balance
    
}

// I want addPayment function to add payment when savePayment returns true
// Then when saving the payment we save amount from user_id into requested userid account 
//The amount must be deposted from a positive account and the amount to be add from one account must be greater than the amount to avoiding a snenario were by user tries to add payment from account which is more than the current balance
//Also, when adding payment its important to use requested user_id so that when saving the payemnt to the database it must not have a null value for it to be successfully stored. 