
import datetime
import Math
#defining the class Patient
class Patient:

    #defining a constructor and attributes of class Patient
    def __init__(self,id,status,dischargeDate,outcome):
        self.id = id
        self.status=status
        self.dischargeDate=dischargeDate
        self.outcome=outcome
    
    def isFollowUpDue(self,Patient,today):
      try:  
          if self.status =="discharged" and self.outcome != "deceased":
            
           discharge = dischargeDate
           discharge = dischargeDate
           current = Date(datetime.date)
           diffDays = Math.floor((current.getTime()-discharge.getTime())/ (1000*60*60*24))
          if diffDays >= 7:
            return diffDays
      except IOError:
            print("Records can not be accessed")
      return False


    
    
    