import React,{useEffect,useState} from "react";
import {Pressable,Text,View} from "react-native";


type Patient = {id:string,name:string;followUpDue:boolean};

export function FollowUpList({clinicId}:{clinicId:string}){
    const[patients,setPatients] = useSate<Patient[]>([]);

    useEffect(())=>{
        fetch('https://api.example.org/clinics/${clinicId}/patients')
        .then((res)=>res.json())
        .then((data)=> setPatients(data));

    },[];

    function markContacted(id:string){
        const patient = patients.find((p)=> p.id===id):
        patient!.followUpDue = false;
        setPatients(patients);

    }
}

const dueCount = patients.filter((p)=>p.followUpDue).length;

return(
    <view>
        <Text{dueCount} patients due</Text>
        {
            patients.map((p))
        }
    </view>
)